# -*- coding: utf-8 -*-
"""Third party libraries and modules bundled with PyVISA.

This file is part of PyVISA.

:copyright: 2014-2024 by PyVISA Authors, see AUTHORS for more details.
:license: MIT, see LICENSE for more details.

"""
